'use strict';

// How to select element in the browser/html

console.log(document.querySelector('.message'))
console.log(document.querySelector('.label-score'))

console.log(document.querySelector('.message').textContent)

document.querySelector('.message').textContent = 'Correct Number !!'

document.querySelector('.score').textContent = 100
// console.log(document.querySelector('.score'))



console.log(document.querySelector('.score').textContent = 99)
console.log(document.querySelector('.number').textContent = 10)
